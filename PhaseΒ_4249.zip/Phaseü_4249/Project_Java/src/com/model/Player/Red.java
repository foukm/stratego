package com.model.Player;

public class Red extends Player {

    public Red(boolean reduced ) {
        super("Red", false,false, reduced);
    }
}
