package com.model.Player;

public class Blue extends Player {
    public Blue(boolean reduced) {
        super("Blue", false,false,reduced);
    }
}
