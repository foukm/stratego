package com.model.Piece.Moveable;

public class Scout extends Moveable {
    public Scout(int x, int y, int times, String name, String nameOfTeam, boolean extsts, int katataxi, int validPositions) {
        super(x, y, times, name, nameOfTeam, extsts, 2, validPositions);
    }
}
