package com.model.Piece.Moveable;

public class Knight extends Moveable
{
    public Knight(int x, int y, int times, String name, String nameOfTeam, boolean extsts, int katataxi, int validPositions) {
        super(x, y, times, name, nameOfTeam, extsts, 8 , validPositions);
    }
}
