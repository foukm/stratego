package com.model.Piece.Moveable;

public class Dragon extends Moveable {
    public Dragon(int x, int y, int times, String name, String nameOfTeam, boolean extsts, int katataxi, int validPositions) {
        super(x, y, times, name, nameOfTeam, extsts, 10, validPositions);
    }
}
