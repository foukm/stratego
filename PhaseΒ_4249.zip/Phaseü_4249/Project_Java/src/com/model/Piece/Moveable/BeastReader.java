package com.model.Piece.Moveable;

public class BeastReader extends Moveable {
    public BeastReader(int x, int y, int times, String name, String nameOfTeam, boolean extsts, int katataxi, int validPositions) {
        super(x, y, times, name, nameOfTeam, extsts, 7, validPositions);
    }
}
