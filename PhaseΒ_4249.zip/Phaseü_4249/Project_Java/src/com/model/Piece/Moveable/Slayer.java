package com.model.Piece.Moveable;

public class Slayer extends Moveable {
    public Slayer(int x, int y, int times, String name, String nameOfTeam, boolean extsts, int katataxi, int validPositions) {
        super(x, y, times, name, nameOfTeam, extsts, 1, validPositions);
    }
}
