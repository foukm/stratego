package com.model.Piece.Unmoveable;

public class Bomb extends Unmoveable{
    public Bomb(int x, int y, int times, String name, String nameOfTeam, boolean exists) {
        super(x, y, times, name,nameOfTeam, exists);
    }
}
