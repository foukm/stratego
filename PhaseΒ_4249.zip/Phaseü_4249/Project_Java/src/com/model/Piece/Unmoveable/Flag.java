package com.model.Piece.Unmoveable;

public class Flag extends Unmoveable{

    public Flag(int x, int y, int times, String name,String nameOfTeam, boolean exists) {
        super(x, y, times, name,nameOfTeam, exists);
    }
}
